import matplotlib.pyplot as plt
fp=open("tcp-example3.tr","r")

enqueue = {}

store0 = {}
store1 = {}
store2 = {}

p = '+'
q = '-'
s0 = "0"
s1 = "1"
s2 = "2"

for i in fp:
    token = i.split()
    eqdq = token[0]
    time = float(token[1])
    node = token[2]
    node = node[10]
    if node==s0.strip():
        seq = token[36]
        index = node+seq
        st = float(time)*1000
        if(eqdq==p.strip()):
            enqueue[index] = time
        elif(eqdq==q.strip()):
            en = float(enqueue[index])*1000
            store0[time] = (st-en)
    elif node==s1.strip():
        seq = token[36]
        index = node+seq
        st = float(time)*1000
        if(eqdq==p.strip()):
            enqueue[index] = time
        elif(eqdq==q.strip()): 
            en = float(enqueue[index])*1000  
            store1[time] = (st-en)
    elif node==s2.strip():
        seq = token[36]
        index = node+seq
        st = float(time)*1000
        if(eqdq==p.strip()):
            enqueue[index] = time
        elif(eqdq==q.strip()):
            en = float(enqueue[index])*1000
            store2[time] = (st-en)

plt.scatter(store0.keys(), store0.values(), color = 'black', s=2)
plt.xlabel("Time t (sec)")
plt.ylabel("Queuing delay (sec)")
plt.title("3 c) Queuing Delay with Time Node 0")
plt.grid()
plt.show()

plt.scatter(store1.keys(), store1.values(), color = 'hotpink', s=2)
plt.xlabel("Time t (sec)")
plt.ylabel("Queuing delay (sec)")
plt.title("3 c) Queuing Delay with Time Node 1")
plt.grid()
plt.show()

plt.scatter(store2.keys(), store2.values(), color = 'purple', s=2)
plt.xlabel("Time t (sec)")
plt.ylabel("Queuing delay (sec)")
plt.title("3 c) Queuing Delay with Time Node 2")
plt.grid()
plt.show()