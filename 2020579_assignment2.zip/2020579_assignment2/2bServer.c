#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <pthread.h>
#define PORT 8080

pthread_mutex_t lock;

void error(char *msg) {
    perror(msg); 
    exit(0);
}

long factorial(long n){
	if(n==1||n==2){
		return n;
	}
	else{
		return n*factorial(n-1);
	}
}

int main(int argc, char const* argv[]){
	int server_fd, new_socket, valread;
	struct sockaddr_in address, cli_addr;
	int opt = 1;
	int addrlen = sizeof(address);
	int cli_addrlen = sizeof(cli_addr);
	// char buffer[1024] = { 0 };
	char *buffer = (char *) calloc(1024, sizeof(char));
	// char* hello = "Hello from server";
	char* confirm = (char *) calloc(1024, sizeof(char));
	char* res = (char *) calloc(1024, sizeof(char));

	//create file
	// int fd = open("ans2.txt", O_RDWR | O_CREAT); 
	FILE *fd = fopen("ans2.txt", "w");

	pid_t childpid;

	// Creating socket file descriptor
	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	// Forcefully attaching socket to the port 8080
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);

	// Forcefully attaching socket to the port 8080
	if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
	if (listen(server_fd, 10) < 0) {
		perror("listen");
		exit(EXIT_FAILURE);
	}
	// if ((new_socket = accept(server_fd, (struct sockaddr*)&cli_addr,(socklen_t*)&cli_addrlen))< 0) {
	// 	perror("accept");
	// 	exit(EXIT_FAILURE);
	// }
	printf("%u\n", ntohs(cli_addr.sin_port));
	printf("%u\n", cli_addr.sin_addr.s_addr);

	if (pthread_mutex_init(&lock, NULL) != 0) {
        printf("\n mutex init has failed\n");
        return 1;
    }

	int cnt = 0;
	for(int j = 0; j<10; j++) {
		// Accept clients and
		// store their information in cliAddr
		if ((new_socket = accept(server_fd, (struct sockaddr*)&cli_addr,(socklen_t*)&cli_addrlen))< 0) {
			perror("accept");
			exit(EXIT_FAILURE);
		}

		// Displaying information of
		// connected client
		printf("Connection accepted from %s:%d\n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));

		// Print number of clients
		// connected till now
		printf("Clients connected: %d\n",++cnt);

		// Creates a child process
		if ((childpid = fork()) == 0) {
			
			for(int i = 0; i<20; i++){
				// getsockname(new_socket, (struct sockaddr *) &cli_addr, (socklen_t*)&cli_addrlen);
				char *ip = inet_ntoa(cli_addr.sin_addr);
				int port = ntohs(cli_addr.sin_port);
				// printf("[%s:%u] > ", inet_ntoa(client.sin_addr), ntohs(client.sin_port));
				valread = read(new_socket, buffer, 1024);
				long x;
				sscanf(buffer, "%ld", &x);
				// printf("message received %s\n", buffer);
				printf("message received %ld\n", x);
				long fac = factorial(x);
				sprintf(confirm, "%ld", fac);
				sprintf(res, "result is %ld , client IP addr: %s , port number: %u\n", fac, ip, port);

				pthread_mutex_lock(&lock);
				// int sz = write(fd, res, strlen(res));
				fprintf(fd, "result is %ld , client IP addr: %s , port number: %u\n", fac, ip, port);
				pthread_mutex_unlock(&lock);

				send(new_socket, confirm, strlen(confirm), 0);
				// printf("Hello message sent\n");
			}
			
			// closing the connected socket
			close(new_socket);
			exit(0);
			// printf("EOOONG end %d\n", j);
			// Closing the server socket id
		}
		// printf("end end %d\n", j);
	}
	// closing the listening socket
	// close(fd);
	// printf("fffffFFFFFFFFFFFFFFEND START\n");
	free(buffer);
    free(confirm);
    free(res);

	fclose(fd);
	shutdown(server_fd, SHUT_RDWR);
	pthread_mutex_destroy(&lock);
	// printf("EEEEEEENDDDDDDD_END\n");
	exit(EXIT_SUCCESS);
	// printf("EEEEEEENDDDoooooooDDD_END\n");
	return 0;
}
