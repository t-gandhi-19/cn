//epoll
#include <stdio.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <errno.h> 
#include <sys/select.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <poll.h>
#include <sys/epoll.h>
#include <sys/types.h>

#define MAX_CONNECTIONS 11
#define PORT 8080

pthread_mutex_t lock;

void error(char *msg) {
    perror(msg); 
    exit(0);
}

unsigned long factorial(unsigned long n){
	if(n==1||n==2){
		return n;
	}
	else{
		return n*factorial(n-1);
	}
}

int main () {
    //socket creation
    int server_fd, new_fd, ret_val, i;
	struct sockaddr_in address, cli_addr;
	int opt = 1;
	int addrlen = sizeof(address);
	int cli_addrlen = sizeof(cli_addr);
	char *buffer = (char *) calloc(1024, sizeof(char));
	char *confirm = (char *) calloc(1024, sizeof(char));
	char *res = (char *) calloc(1024, sizeof(char));

	//create file
	// int fd = open("ans4.txt", O_RDWR | O_CREAT); 
	FILE *fd = fopen("ans6.txt", "w");
    fclose(fd);

	// Creating socket file descriptor
	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	// Forcefully attaching socket to the port 8080
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);

	// Forcefully attaching socket to the port 8080
	if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
	if (listen(server_fd, 10) < 0) {
		perror("listen");
		exit(EXIT_FAILURE);
	}

    if (pthread_mutex_init(&lock, NULL) != 0) {
        printf("\n mutex init has failed\n");
        return 1;
    }

    // int all_connections[MAX_CONNECTIONS];
    // struct pollfd *pfds;
    // int nfds = MAX_CONNECTIONS-1, num_open_fds = nfds;
    // struct pollfd pollfds[MAX_CONNECTIONS+1];
    int port[MAX_CONNECTIONS+1];
    char ip[MAX_CONNECTIONS+1][100];

    struct epoll_event ev, events[MAX_CONNECTIONS];
    int listen_sock, conn_sock, nfds, epollfd;
    // int nfds = MAX_CONNECTIONS-1, num_open_fds = nfds;

    epollfd = epoll_create1(0);
    if (epollfd == -1) {
        perror("epoll_create1");
        exit(EXIT_FAILURE);
    }

    listen_sock = server_fd;

    ev.events = EPOLLIN;
    ev.data.fd = listen_sock;
    if (epoll_ctl(epollfd, EPOLL_CTL_ADD, listen_sock, &ev) == -1) {
        perror("epoll_ctl: listen_sock");
        exit(EXIT_FAILURE);
    }

    // pollfds[0].fd = server_fd;
    // pollfds[0].events = POLLIN;
    int useClient = 0;
    // for (int i = 1; i < MAX_CONNECTIONS; i++){
    //     pollfds[i].fd = 0;
    //     pollfds[i].events = POLLIN;
    //     port[i] = 0;
    // }

    while(1) {
        // invoke poll() and wait!
        // ret_val = epoll_wait(epollfd, useClient+1, 5000);
        nfds = epoll_wait(epollfd, events, MAX_CONNECTIONS, -1);
        if(nfds == -1) {
            perror("epoll_wait");
            exit(EXIT_FAILURE);
        }

        for (int n = 0; n < nfds; ++n) {
            if (events[n].data.fd == listen_sock) {
                conn_sock = accept(listen_sock, (struct sockaddr *) &cli_addr, &cli_addrlen);
                if (conn_sock == -1) {
                    perror("accept");
                    exit(EXIT_FAILURE);
                }
                // setnonblocking(conn_sock);
                ev.events = EPOLLIN | EPOLLET;
                ev.data.fd = conn_sock;
                port[n] = ntohs(cli_addr.sin_port);
                strcpy(ip[n], inet_ntoa(cli_addr.sin_addr));
                if (epoll_ctl(epollfd, EPOLL_CTL_ADD, conn_sock, &ev) == -1) {
                    perror("epoll_ctl: conn_sock");
                    exit(EXIT_FAILURE);
                }
            } 
            else {
                bzero(buffer, sizeof(buffer));
                bzero(res, sizeof(res));
                bzero(confirm, sizeof(confirm));
                int bufSize = read(events[n].data.fd, buffer, 1024);
                if (bufSize == -1 || bufSize == 0) {
                    events[n].data.fd = 0;
                    events[n].events = 0;
                    // printf("end\n");
                    useClient--;
                }
                else{
                    unsigned long x = 0;
                    sscanf(buffer, "%lu", &x);
                    // printf("message received %s\n", buffer);
                    printf("message received %lu from fd %d [index, i: %d]\n", x,events[n].data.fd , i);
                    unsigned long fac = factorial(x);
                    sprintf(confirm, "%lu", fac);
                    sprintf(res, "result is %lu , client IP addr: %s , port number: %u\n", fac, ip[i], port[i]);
                    pthread_mutex_lock(&lock);
                    // int sz = write(fd, res, strlen(res));
                    fd = fopen("ans6.txt", "a");
                    fprintf(fd, "result is %lu , client IP addr: %s , port number: %u\n", fac, ip[i], port[i]);
                    fclose(fd);
                    pthread_mutex_unlock(&lock);
                    write(events[n].data.fd, confirm, strlen(confirm)); 
                }
            }
        }
    }
        // poll() woke up. Identify the fd that has events
        // if(ret_val >= 0) {
        //     //check if fd with event is server fd
        //     if (pollfds[0].revents & POLLIN) {
        //         // accept ne wconnection
        //         printf("RETURNED FD IS %d (server's fd)\n ", server_fd);
        //         int new_fd = accept(server_fd, (struct sockaddr *)&cli_addr, (socklen_t*)&cli_addrlen);
        //         if (new_fd >= 0) {
        //             printf("Accepted a new connection with fd: %d\n", new_fd);
        //             printf("Connection accepted from %s:%d\n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
        //             for (int i=1; i < MAX_CONNECTIONS; i++) {
        //                 if (pollfds[i].fd == 0) {
        //                     pollfds[i].fd = new_fd;
        //                     pollfds[i].events = POLLIN;
        //                     port[i] = ntohs(cli_addr.sin_port);
        //                     strcpy(ip[i], inet_ntoa(cli_addr.sin_addr));
        //                     useClient++;
        //                     break;
        //                 }
        //             }
        //         }
        //         else{
        //             fprintf(stderr, "ACCEPT FAILED [%s]\n", strerror(errno));
        //         }
        //         ret_val--;
        //         if (!ret_val) continue;
        //     }
            // check if fd with event is a non server fd


        //     for(i=1; i<MAX_CONNECTIONS; i++) {
        //         if (pollfds[i].fd > 0 && pollfds[i].revents & POLLIN){
        //             // memset(buf, 0, sizeof(buf));
        //             // read incoming data
        //             bzero(buffer, sizeof(buffer));
        //             bzero(res, sizeof(res));
        //             bzero(confirm, sizeof(confirm));
        //             int bufSize = read(pollfds[i].fd, buffer, 1024);
        //             if (bufSize == -1 || bufSize == 0) {
        //                 pollfds[i].fd = 0;
        //                 pollfds[i].events = 0;
        //                 pollfds[i].revents = 0;
        //                 // printf("end\n");
        //                 useClient--;
        //             }
        //             else{
        //                 unsigned long x = 0;
        //                 sscanf(buffer, "%lu", &x);
        //                 // printf("message received %s\n", buffer);
        //                 printf("message received %lu from fd %d [index, i: %d]\n", x, pollfds[i].fd, i);
        //                 unsigned long fac = factorial(x);
        //                 sprintf(confirm, "%lu", fac);
        //                 sprintf(res, "result is %lu , client IP addr: %s , port number: %u\n", fac, ip[i], port[i]);
        //                 pthread_mutex_lock(&lock);
        //                 // int sz = write(fd, res, strlen(res));
        //                 fd = fopen("ans5.txt", "a");
        //                 fprintf(fd, "result is %lu , client IP addr: %s , port number: %u\n", fac, ip[i], port[i]);
        //                 fclose(fd);
        //                 pthread_mutex_unlock(&lock);
        //                 write(pollfds[i].fd, confirm, strlen(confirm)); 
        //             }
        //         }
        //     }
        // }
        // else{
        //     printf("FAILED TO CONNECT. \n");
        // }
    // printf("endEEE\n");
    // close(fd);
	// printf("fffffFFFFFFFFFFFFFFEND START\n");
	free(buffer);
    free(confirm);
    free(res);

	// fclose(fd);
	shutdown(server_fd, SHUT_RDWR);
	pthread_mutex_destroy(&lock);
	// printf("EEEEEEENDDDDDDD_END\n");
	exit(EXIT_SUCCESS);
    return 0;
}



