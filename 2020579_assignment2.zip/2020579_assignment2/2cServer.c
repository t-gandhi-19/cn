#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <pthread.h>
#define PORT 8080

pthread_mutex_t lock;
// int fd;
FILE *fd;

struct data{
    char *ip;
	int port;
    int sock_fd;
};

void error(char *msg) {
    perror(msg); 
    exit(0);
}

long factorial(long n){
	if(n==1||n==2){
		return n;
	}
	else{
		return n*factorial(n-1);
	}
}

void *sendReq(void *vargp){
    struct data *s;
    s = (struct data *)vargp;
    char *ip = s->ip;
    int port = s->port;
    int new_socket = s->sock_fd;
    printf("port: %d\n", port);

    char *buffer = (char *) calloc(1024, sizeof(char));
	char* confirm = (char *) calloc(1024, sizeof(char));
	char* res = (char *) calloc(1024, sizeof(char));
    
    int valread;

    for(int i = 0; i<20; i++){
        // getsockname(new_socket, (struct sockaddr *) &cli_addr, (socklen_t*)&cli_addrlen);
        
        // printf("[%s:%u] > ", inet_ntoa(client.sin_addr), ntohs(client.sin_port));
        valread = read(new_socket, buffer, 1024);
        long x;
        sscanf(buffer, "%ld", &x);
        // printf("message received %s\n", buffer);
        printf("message received %ld\n", x);
        long fac = factorial(x);
        sprintf(confirm, "%ld", fac);
        sprintf(res, "result is %ld , client IP addr: %s , port number: %u\n", fac, ip, port);

        // pthread_mutex_lock(&lock);
        // int sz = write(fd, res, strlen(res));
        fprintf(fd, "result is %ld , client IP addr: %s , port number: %u\n", fac, ip, port);
        // pthread_mutex_unlock(&lock);

        send(new_socket, confirm, strlen(confirm), 0);
        // printf("Hello message sent\n");
        
    }
    close(new_socket);
    
    free(buffer);
    free(confirm);
    free(res);
}

int main(int argc, char const* argv[])
{
	int server_fd, valread;
	struct sockaddr_in address, cli_addr;
	int opt = 1;
	int addrlen = sizeof(address);
	int cli_addrlen = sizeof(cli_addr);
	char *buffer = (char *) calloc(1024, sizeof(char));
	char* confirm = (char *) calloc(1024, sizeof(char));
	char* res = (char *) calloc(1024, sizeof(char));
    
    fd = fopen("ans3.txt", "w");
	//create file
	// int fd = open("ans.txt", O_RDWR | O_CREAT); 
	// FILE *fd = fopen("ans2.txt", "w");

	// Creating socket file descriptor
	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	// Forcefully attaching socket to the port 8080
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}

	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);

	// Forcefully attaching socket to the port 8080
	if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}

    if (listen(server_fd, 10) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    pthread_t tid[10];
    for(int i = 0; i<10; i++) {   
        int new_socket; 
        if ((new_socket = accept(server_fd, (struct sockaddr*)&cli_addr,(socklen_t*)&cli_addrlen))< 0) {
        	perror("accept");
        	exit(EXIT_FAILURE);
        }

        int cnt = 0;
        printf("Connection accepted from %s:%d\n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
        // Print number of clients
        // connected till now
        printf("Clients connected: %d\n\n",++cnt);

        struct data s1;
        s1.ip = inet_ntoa(cli_addr.sin_addr);
        s1.port = ntohs(cli_addr.sin_port);
        s1.sock_fd = new_socket;

        //give to thread
        pthread_create(&tid[i], NULL, sendReq, (void *)&s1);
    }
    for(int i = 0; i<10; i++){
        pthread_join(tid[i], NULL);
    }
    pthread_exit(NULL);
	// closing the listening socket
	// close(fd);
	fclose(fd);
	shutdown(server_fd, SHUT_RDWR);
	pthread_mutex_destroy(&lock);
	exit(EXIT_SUCCESS);
	return 0;
}
