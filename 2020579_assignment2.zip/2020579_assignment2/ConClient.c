#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#define PORT 8080

// int pthread_create(&tid, NULL, &sendReq, (void *)&tid);
// int pthread_create(pthread_t *restrict thread,const pthread_attr_t *restrict attr, void *(*start_routine)(void *),void *restrict arg);
// void pthread_exit(void *retval)

void error(char *msg) {
    perror(msg); 
    exit(0);
}

int sendReq(void *vargp){
    int *num = (int *)vargp;
    printf("client number: %d\n", *num);
    int sock = 0, valread, client_fd;
	struct sockaddr_in serv_addr;
	// char buffer[1024] = { 0 };
	char *buffer = (char *) calloc(1024, sizeof(char));
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("\n Socket creation error \n");
		return -1;
	}
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(PORT);
	serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1"); // al
	if ((client_fd = connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr))) < 0) {
		printf("\nConnection Failed \n");
		return -1;
	}
    for(int i = 1; i<=20; i++){
        char msg[100];
        sprintf(msg, "%d", i);
	    send(sock, msg, strlen(msg), 0);
	    printf("message sent %s\n", msg);
	    valread = read(sock, buffer, 1024);
	    printf("%s\n", buffer);
    }
	// closing the connected socket
	close(client_fd);
}

int main(int argc, char const* argv[]){
	pthread_t tid;
    for (int i = 0; i < 10; i++){
        
        pthread_create(&tid, NULL, &sendReq, (void *)&tid);
    }
    pthread_exit(NULL);
	return 0;
}