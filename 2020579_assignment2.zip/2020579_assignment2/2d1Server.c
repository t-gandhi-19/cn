//select
#include <stdio.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <errno.h> 
#include <sys/select.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <pthread.h>
#include <arpa/inet.h>

#define MAX_CONNECTIONS 11
#define PORT 8080

pthread_mutex_t lock;
// int fd;
// FILE *fd;

void error(char *msg) {
    perror(msg); 
    exit(0);
}

unsigned long factorial(unsigned long n){
	if(n==1||n==2){
		return n;
	}
	else{
		return n*factorial(n-1);
	}
}

int main () {
    //socket creation
    int server_fd, new_fd, ret_val, i;
	struct sockaddr_in address, cli_addr;
	int opt = 1;
	int addrlen = sizeof(address);
	int cli_addrlen = sizeof(cli_addr);
	char *buffer = (char *) calloc(1024, sizeof(char));
	char *confirm = (char *) calloc(1024, sizeof(char));
	char *res = (char *) calloc(1024, sizeof(char));

	//create file
	// int fd = open("ans4.txt", O_RDWR | O_CREAT); 
	FILE *fd = fopen("ans4.txt", "w");
    fclose(fd);

	// Creating socket file descriptor
	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	// Forcefully attaching socket to the port 8080
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);

	// Forcefully attaching socket to the port 8080
	if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
	if (listen(server_fd, 10) < 0) {
		perror("listen");
		exit(EXIT_FAILURE);
	}

    if (pthread_mutex_init(&lock, NULL) != 0) {
        printf("\n mutex init has failed\n");
        return 1;
    }

    fd_set read_fd_set; 
    int all_connections[MAX_CONNECTIONS];
    int port[MAX_CONNECTIONS+1];
    char ip[MAX_CONNECTIONS+1][100];

    /* Initialize all connections and set the first entry to server fd*/
    for (i=0;i< MAX_CONNECTIONS; i++) {
        all_connections[i] = -1; 
        port[i] = 0;
        // strcpy(ip[i], (char *) calloc(1024, sizeof(char));
    }
    all_connections[0] = server_fd;

    while (1) {
        FD_ZERO(&read_fd_set); 
        /* Set the fd_set before passing it to the select*/
        for (i=0;i< MAX_CONNECTIONS; i++) { 
            if (all_connections[i] >= 0) {
                FD_SET(all_connections[i], &read_fd_set); 
            }
        }
        /* Invoke select() and then wait! */ 
        ret_val = select(FD_SETSIZE, &read_fd_set, NULL, NULL, NULL);
        /* select() woke up. Identify the fd that has events */ 
        int cnt = 0;
        if (ret_val>= 0) {
            printf("Select returned with %d\n", ret_val); 
            /* Check if the fd with event is the server fd */ 
            if (FD_ISSET(server_fd, &read_fd_set)) { 
                /* accept the new connection*/ 
                printf("Returned fd is %d (server's fd)\n", server_fd); 
                new_fd = accept(server_fd, (struct sockaddr*)&cli_addr, (socklen_t*)&cli_addrlen); 
                if (new_fd >= 0) {
                    printf("Accepted a new connection with fd: %d\n", new_fd);
                    printf("Connection accepted from %s:%d\n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
                    printf("Clients connected: %d\n",++cnt);
                    for (i=1;i< MAX_CONNECTIONS;i++) {
                        if (all_connections[i] < 0) { 
                            all_connections[i] = new_fd; 
                            port[i] = ntohs(cli_addr.sin_port);
                            strcpy(ip[i], inet_ntoa(cli_addr.sin_addr));
                            break;
                        }
                    }
                }
                else {
                    fprintf(stderr, "accept failed [%s]\n", strerror(errno));
                }
                ret_val--; 
                if (!ret_val) continue;
            }
            /* Check if the fd with event is a non-server fd */ 
            for (i=1;i< MAX_CONNECTIONS;i++) {
                if ((all_connections[i] > 0) && (FD_ISSET(all_connections[i], &read_fd_set))) {
                    /* read incoming data */
                    // printf("Returned fd is %d [index, i: %d]\n", all_connections[i], i); 
                    bzero(buffer, sizeof(buffer));
                    bzero(res, sizeof(res));
                    bzero(confirm, sizeof(confirm));
                    ret_val = recv(all_connections[i], buffer, 1024, 0); 
                    if (ret_val == 0) {
                        printf("Closing connection for fd: %d\n", all_connections[i]);
                        close(all_connections[i]); 
                        all_connections[i]= -1; /* Connection is now closed */
                    }
                    if (ret_val > 0) { 
                        // printf("Received data (len %d bytes, fd: %d): %s\n", ret_val, all_connections[i], buffer);
                        unsigned long x = 0;
                        sscanf(buffer, "%lu", &x);
                        // printf("message received %s\n", buffer);
                        printf("message received %lu from fd %d [index, i: %d]\n", x, all_connections[i], i);
                        unsigned long fac = factorial(x);
                        sprintf(confirm, "%lu", fac);
                        sprintf(res, "result is %lu , client IP addr: %s , port number: %u\n", fac, ip[i], port[i]);
                        pthread_mutex_lock(&lock);
                        // int sz = write(fd, res, strlen(res));
                        fd = fopen("ans4.txt", "a");
                        fprintf(fd, "result is %lu , client IP addr: %s , port number: %u\n", fac, ip[i], port[i]);
                        fclose(fd);
                        pthread_mutex_unlock(&lock);
                        send(all_connections[i], confirm, strlen(confirm), 0);  
                    }
                    if (ret_val == -1) {
                        printf("recv() failed for fd: %d [%s]\n",all_connections[i], strerror(errno));
                        break;
                    }
                }
                ret_val--;
                if (!ret_val) continue;
            }
        }
    }

    /* Close all the sockets */ 
    for (i=0;i< MAX_CONNECTIONS;i++) { 
        if (all_connections[i] > 0) {
            close(all_connections[i]);
        }
    }
    // close(fd);
	// printf("fffffFFFFFFFFFFFFFFEND START\n");
	free(buffer);
    free(confirm);
    free(res);

	// fclose(fd);
	shutdown(server_fd, SHUT_RDWR);
	pthread_mutex_destroy(&lock);
	// printf("EEEEEEENDDDDDDD_END\n");
	exit(EXIT_SUCCESS);
	// printf("EEEEEEEND
    return 0;
}

